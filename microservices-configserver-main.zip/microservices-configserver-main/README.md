# microservices-config
Central repository configurations for Eazy Bank Microservices
